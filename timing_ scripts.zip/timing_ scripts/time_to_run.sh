#!/bin/bash

sudo /home/abdulmonum/SPADE/bin/spade start

sleep 1


start_time=$(($(date +%s%N)/1000000))

sudo /home/abdulmonum/SPADE/bin/spade query < inputs

elapsed=$(( $(($(date +%s%N)/1000000)) - start_time ))
echo $elapsed
echo $elapsed >> runtimes

sleep 1

sudo /home/abdulmonum/SPADE/bin/spade stop